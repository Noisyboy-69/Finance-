# Gestore Finanze V11 — finale

Versione Android locale-first, senza accesso alle notifiche.

## Funzioni
- inserimento/modifica/eliminazione di spese ed entrate;
- stipendio mensile previsto/effettivo e giorno stipendio configurabile;
- saldo attuale e limite di scoperto separati;
- spese ricorrenti con equivalenza mensile (mensile, bimestrale, trimestrale, annuale);
- budget per categoria modificabili;
- calcolo dinamico di "Puoi spendere davvero" e limite settimanale;
- modalità di recupero quando il saldo è negativo;
- obiettivi di risparmio con contributo mensile;
- investimenti, ETF, azioni e crypto con capitale, valore, PAC e analisi descrittiva;
- apertura assistita di Revolut, senza eseguire operazioni;
- dati persistenti in SQLite;
- nessun NotificationListener e nessun permesso POST_NOTIFICATIONS.

Il motore finanziario calcola i numeri in modo deterministico. L'assistente fornisce spiegazioni e scenari, non esegue ordini finanziari.
