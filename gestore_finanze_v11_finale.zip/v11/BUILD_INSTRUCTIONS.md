# Prima compilazione Android

1. Installare Flutter stable e Android Studio.
2. Aprire un terminale nella cartella `gestore_finanze_v10`.
3. Eseguire `flutter pub get`.
4. Eseguire `flutter create .` solo se mancano i file wrapper generati da Flutter; non sostituire `lib/` e `pubspec.yaml`.
5. Verificare con `flutter doctor` che Android toolchain sia configurata.
6. Collegare il Samsung S24 Ultra con debug USB oppure usare un emulatore.
7. Eseguire `flutter run`.
8. Per APK: `flutter build apk --release`.

## Revolut
Dopo l'installazione dell'app, Android richiede che l'utente abiliti manualmente il servizio `Gestore Finanze` in:
Impostazioni > Accesso notifiche.

L'app legge solo le notifiche del pacchetto Revolut e non effettua movimenti bancari.
