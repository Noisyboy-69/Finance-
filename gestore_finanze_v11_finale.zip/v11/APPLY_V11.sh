#!/usr/bin/env bash
set -e
# Run this from the existing Flutter project root after extracting the V11 archive into v11_source.
SRC="$(cd "$(dirname "$0")" && pwd)"
rm -f lib/services/revolut_notification_bridge.dart
rm -f android/app/src/main/kotlin/com/gestorefinanze/app/RevolutNotificationListener.kt
cp -r "$SRC/lib/." lib/
cp -r "$SRC/android/app/src/main/." android/app/src/main/
cp "$SRC/android/build.gradle" android/build.gradle
cp "$SRC/android/app/build.gradle" android/app/build.gradle
cp "$SRC/android/gradle.properties" android/gradle.properties
if [ -f android/gradle/wrapper/gradle-wrapper.properties ]; then
  sed -i 's#distributionUrl=.*#distributionUrl=https\\://services.gradle.org/distributions/gradle-8.14-bin.zip#' android/gradle/wrapper/gradle-wrapper.properties
fi
cp "$SRC/pubspec.yaml" pubspec.yaml
flutter pub get
flutter build apk --release --android-skip-build-dependency-validation
