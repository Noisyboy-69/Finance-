import '../models/models.dart';
class FinancialEngine {
  static FinancialPlan build({required MonthIncome income,required CurrentAccountStatus account,required List<RecurringExpense> recurring,required List<Movement> movements,required List<Goal> goals,required List<InvestmentPosition> investments,DateTime? now,int salaryDay=15}){
    final d=now??DateTime.now();
    final recurringMonthly=recurring.fold(0.0,(s,e)=>s+e.monthlyEquivalent);
    final monthMovements=movements.where((m)=>m.date.year==d.year&&m.date.month==d.month).toList();
    final spent=monthMovements.where((m)=>m.kind==MovementKind.expense).fold(0.0,(s,m)=>s+m.amount);
    final earned=monthMovements.where((m)=>m.kind==MovementKind.income).fold(0.0,(s,m)=>s+m.amount);
    final recovery=account.currentBalance<0?((income.amount*0.20).clamp(0,account.currentBalance.abs())).toDouble():0.0;
    final goalContributions=goals.fold(0.0,(s,g)=>s+g.monthlyContribution);
    final investmentContributions=investments.fold(0.0,(s,p)=>s+p.monthlyPac);
    final safeBase=account.currentBalance>0?account.currentBalance:0.0;
    final obligations=recurringMonthly+recovery+goalContributions+investmentContributions;
    // currentBalance is treated as the real snapshot of the account: it already
    // contains salary and past movements, so salary is not added a second time.
    final spendable=(safeBase-obligations).clamp(0,double.infinity).toDouble();
    var next=DateTime(d.year,d.month,salaryDay.clamp(1,28));if(!next.isAfter(d))next=DateTime(d.year,d.month+1,salaryDay.clamp(1,28));
    final days=next.difference(d).inDays.clamp(1,62);final weekly=spendable/(days/7).clamp(1,9);
    FinancialStatus status=FinancialStatus.stable;
    if(account.currentBalance<0){status=account.overdraftLimit>0&&account.currentBalance.abs()>=account.overdraftLimit*.9?FinancialStatus.critical:FinancialStatus.recovery;}else if(income.amount>0&&spendable<income.amount*.15)status=FinancialStatus.attention;
    return FinancialPlan(income:income.amount,recurringMonthly:recurringMonthly,spentThisMonth:spent,earnedThisMonth:earned,currentBalance:account.currentBalance,overdraftLimit:account.overdraftLimit,recoveryAmount:recovery,spendableUntilSalary:spendable,weeklySpendable:weekly,daysUntilSalary:days,status:status,goalContributions:goalContributions,investmentContributions:investmentContributions);
  }
}
