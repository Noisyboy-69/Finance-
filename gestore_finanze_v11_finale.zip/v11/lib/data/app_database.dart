import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

class AppDatabase {
  static final instance=AppDatabase._(); AppDatabase._(); Database? _db;
  Future<Database> get database async=>_db??=await _open();
  Future<Database> _open() async=>openDatabase(join(await getDatabasesPath(),'gestore_finanze.db'),version:4,onCreate:(db,v)async=>_schema(db),onUpgrade:(db,old,v)async{
    if(old<2){await db.execute("ALTER TABLE movements ADD COLUMN raw_text TEXT NOT NULL DEFAULT ''");await db.execute('CREATE TABLE IF NOT EXISTS goals (id TEXT PRIMARY KEY,name TEXT NOT NULL,target REAL NOT NULL,current REAL NOT NULL,monthly_contribution REAL NOT NULL DEFAULT 0)');await db.execute('CREATE TABLE IF NOT EXISTS investments (id TEXT PRIMARY KEY,name TEXT NOT NULL,type TEXT NOT NULL,invested REAL NOT NULL,current_value REAL NOT NULL,monthly_pac REAL NOT NULL DEFAULT 0,platform TEXT)');await db.execute('CREATE TABLE IF NOT EXISTS merchant_rules (keyword TEXT PRIMARY KEY,category TEXT NOT NULL)');}
    if(old<3){await db.execute("ALTER TABLE movements ADD COLUMN note TEXT NOT NULL DEFAULT ''");await db.execute("ALTER TABLE movements ADD COLUMN kind TEXT NOT NULL DEFAULT 'expense'");await db.execute("ALTER TABLE recurring_expenses ADD COLUMN day_of_month INTEGER NOT NULL DEFAULT 1");await db.execute('CREATE TABLE IF NOT EXISTS budgets (category TEXT PRIMARY KEY,monthly_limit REAL NOT NULL)');}
    if(old<4){await db.execute('CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY,value TEXT NOT NULL)');}
  });
  Future<void> _schema(Database db)async{
    await db.execute('CREATE TABLE settings (key TEXT PRIMARY KEY,value TEXT NOT NULL)');
    await db.execute('CREATE TABLE incomes (id INTEGER PRIMARY KEY AUTOINCREMENT,year INTEGER NOT NULL,month INTEGER NOT NULL,amount REAL NOT NULL,status TEXT NOT NULL,UNIQUE(year,month))');
    await db.execute('CREATE TABLE account_status (id INTEGER PRIMARY KEY CHECK(id=1),current_balance REAL NOT NULL,overdraft_limit REAL NOT NULL)');
    await db.execute('CREATE TABLE recurring_expenses (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,amount REAL NOT NULL,recurrence TEXT NOT NULL,category TEXT NOT NULL,day_of_month INTEGER NOT NULL DEFAULT 1)');
    await db.execute("CREATE TABLE movements (id TEXT PRIMARY KEY,date TEXT NOT NULL,merchant TEXT NOT NULL,amount REAL NOT NULL,category TEXT NOT NULL,source TEXT NOT NULL,raw_text TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',kind TEXT NOT NULL DEFAULT 'expense')");
    await db.execute('CREATE TABLE goals (id TEXT PRIMARY KEY,name TEXT NOT NULL,target REAL NOT NULL,current REAL NOT NULL,monthly_contribution REAL NOT NULL DEFAULT 0)');
    await db.execute('CREATE TABLE investments (id TEXT PRIMARY KEY,name TEXT NOT NULL,type TEXT NOT NULL,invested REAL NOT NULL,current_value REAL NOT NULL,monthly_pac REAL NOT NULL DEFAULT 0,platform TEXT)');
    await db.execute('CREATE TABLE merchant_rules (keyword TEXT PRIMARY KEY,category TEXT NOT NULL)');
    await db.execute('CREATE TABLE budgets (category TEXT PRIMARY KEY,monthly_limit REAL NOT NULL)');
    await db.execute('CREATE TABLE app_settings (key TEXT PRIMARY KEY,value TEXT NOT NULL)');
  }
  Future<void> saveIncome(MonthIncome x)async=>(await database).insert('incomes',x.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  Future<MonthIncome?> income(int y,int m)async{final r=await(await database).query('incomes',where:'year=? AND month=?',whereArgs:[y,m],limit:1);return r.isEmpty?null:MonthIncome.fromMap(r.first);}
  Future<List<MonthIncome>> incomes()async=>(await(await database).query('incomes',orderBy:'year DESC, month DESC')).map(MonthIncome.fromMap).toList();
  Future<void> saveAccount(CurrentAccountStatus x)async=>(await database).insert('account_status',{'id':1,'current_balance':x.currentBalance,'overdraft_limit':x.overdraftLimit},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<CurrentAccountStatus?> account()async{final r=await(await database).query('account_status',limit:1);if(r.isEmpty)return null;return CurrentAccountStatus(currentBalance:(r.first['current_balance'] as num).toDouble(),overdraftLimit:(r.first['overdraft_limit'] as num).toDouble());}
  Future<int> addRecurring(RecurringExpense x)async=>(await database).insert('recurring_expenses',x.toMap()..remove('id'));
  Future<void> updateRecurring(RecurringExpense x)async=> (await database).update('recurring_expenses',x.toMap()..remove('id'),where:'id=?',whereArgs:[x.id]);
  Future<void> deleteRecurring(int id)async=>(await database).delete('recurring_expenses',where:'id=?',whereArgs:[id]);
  Future<List<RecurringExpense>> recurring()async=>(await(await database).query('recurring_expenses',orderBy:'id DESC')).map(RecurringExpense.fromMap).toList();
  Future<void> addMovement(Movement x)async=>(await database).insert('movements',x.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  Future<void> updateMovement(Movement x)async=>(await database).update('movements',x.toMap(),where:'id=?',whereArgs:[x.id]);
  Future<void> deleteMovement(String id)async=>(await database).delete('movements',where:'id=?',whereArgs:[id]);
  Future<List<Movement>> movements({int? year,int? month})async{final db=await database;String? where;List<Object?>? args;if(year!=null&&month!=null){where='date>=? AND date<?';args=[DateTime(year,month,1).toIso8601String(),DateTime(year,month+1,1).toIso8601String()];}final r=await db.query('movements',where:where,whereArgs:args,orderBy:'date DESC');return r.map(Movement.fromMap).toList();}
  Future<void> saveRule(String keyword,String category)async=>(await database).insert('merchant_rules',{'keyword':keyword.toLowerCase(),'category':category},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<List<CategoryRule>> rules()async=>(await(await database).query('merchant_rules')).map((x)=>CategoryRule(x['keyword'] as String,x['category'] as String)).toList();
  Future<void> saveGoal(Goal x)async=>(await database).insert('goals',x.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  Future<void> deleteGoal(String id)async=>(await database).delete('goals',where:'id=?',whereArgs:[id]);
  Future<List<Goal>> goals()async=>(await(await database).query('goals')).map((x)=>Goal(id:x['id'] as String,name:x['name'] as String,target:(x['target'] as num).toDouble(),current:(x['current'] as num).toDouble(),monthlyContribution:(x['monthly_contribution'] as num).toDouble())).toList();
  Future<void> saveInvestment(InvestmentPosition x)async=>(await database).insert('investments',x.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  Future<void> deleteInvestment(String id)async=>(await database).delete('investments',where:'id=?',whereArgs:[id]);
  Future<List<InvestmentPosition>> investments()async=>(await(await database).query('investments',orderBy:'name')).map(InvestmentPosition.fromMap).toList();
  Future<void> saveBudget(String category,double limit)async=>(await database).insert('budgets',{'category':category,'monthly_limit':limit},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<Map<String,double>> budgets()async{final r=await(await database).query('budgets');return {for(final x in r)x['category'] as String:(x['monthly_limit'] as num).toDouble()};}
  Future<void> setApp(String key,String value)async=>(await database).insert('app_settings',{'key':key,'value':value},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<String?> getApp(String key)async{final r=await(await database).query('app_settings',where:'key=?',whereArgs:[key],limit:1);return r.isEmpty?null:r.first['value'] as String;}
}
class CategoryRule{final String keyword,category;const CategoryRule(this.keyword,this.category);}
