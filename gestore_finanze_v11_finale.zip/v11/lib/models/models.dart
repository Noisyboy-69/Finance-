enum IncomeStatus { estimated, actual }
enum Recurrence { monthly, everyTwoMonths, quarterly, yearly, oneOff }
enum FinancialStatus { stable, attention, recovery, critical }
enum InvestmentType { etf, stock, crypto, other }
enum MovementKind { expense, income }

enum InvestmentViewAction { hold, considerReducing, considerIncreasing, wait, diversify }

const categories = <String>[
  'Alimentari','Casa','Bollette','Auto','Carburante','Trasporti','Rate','Abbonamenti',
  'Ristoranti','Shopping','Tempo libero','Viaggi','Investimenti','Risparmio','Altro'
];

class MonthIncome {
  final int year, month; final double amount; final IncomeStatus status;
  const MonthIncome({required this.year,required this.month,required this.amount,required this.status});
  Map<String,Object?> toMap()=>{'year':year,'month':month,'amount':amount,'status':status.name};
  factory MonthIncome.fromMap(Map<String,Object?> m)=>MonthIncome(year:m['year'] as int,month:m['month'] as int,amount:(m['amount'] as num).toDouble(),status:IncomeStatus.values.firstWhere((e)=>e.name==m['status'],orElse:()=>IncomeStatus.estimated));
}

class CurrentAccountStatus {
  final double currentBalance, overdraftLimit;
  const CurrentAccountStatus({required this.currentBalance,required this.overdraftLimit});
  double get overdraftUsed=>currentBalance<0?currentBalance.abs():0;
  double get overdraftRemaining=>(overdraftLimit-overdraftUsed).clamp(0,overdraftLimit);
}

class RecurringExpense {
  final int? id; final String name,category; final double amount; final Recurrence recurrence; final int dayOfMonth;
  const RecurringExpense({this.id,required this.name,required this.amount,required this.recurrence,required this.category,this.dayOfMonth=1});
  double get monthlyEquivalent{switch(recurrence){case Recurrence.monthly:return amount;case Recurrence.everyTwoMonths:return amount/2;case Recurrence.quarterly:return amount/3;case Recurrence.yearly:return amount/12;case Recurrence.oneOff:return 0;}}
  Map<String,Object?> toMap()=>{'id':id,'name':name,'amount':amount,'recurrence':recurrence.name,'category':category,'day_of_month':dayOfMonth};
  factory RecurringExpense.fromMap(Map<String,Object?> m)=>RecurringExpense(id:m['id'] as int?,name:m['name'] as String,amount:(m['amount'] as num).toDouble(),recurrence:Recurrence.values.firstWhere((e)=>e.name==m['recurrence']),category:m['category'] as String,dayOfMonth:(m['day_of_month'] as num?)?.toInt()??1);
}

class Movement {
  final String id,merchant,category,source,rawText,note; final DateTime date; final double amount; final MovementKind kind;
  const Movement({required this.id,required this.date,required this.merchant,required this.amount,required this.category,required this.source,required this.rawText,this.note='',this.kind=MovementKind.expense});
  Map<String,Object?> toMap()=>{'id':id,'date':date.toIso8601String(),'merchant':merchant,'amount':amount,'category':category,'source':source,'raw_text':rawText,'note':note,'kind':kind.name};
  factory Movement.fromMap(Map<String,Object?> m)=>Movement(id:m['id'] as String,date:DateTime.parse(m['date'] as String),merchant:m['merchant'] as String,amount:(m['amount'] as num).toDouble(),category:m['category'] as String,source:m['source'] as String,rawText:(m['raw_text'] as String?)??'',note:(m['note'] as String?)??'',kind:MovementKind.values.firstWhere((e)=>e.name==(m['kind']??'expense'),orElse:()=>MovementKind.expense));
}

class Goal { final String id,name; final double target,current,monthlyContribution; const Goal({required this.id,required this.name,required this.target,required this.current,this.monthlyContribution=0}); double get progress=>target<=0?0:(current/target).clamp(0,1); Map<String,Object?> toMap()=>{'id':id,'name':name,'target':target,'current':current,'monthly_contribution':monthlyContribution}; }

class InvestmentPosition {
  final String id,name; final InvestmentType type; final double invested,currentValue,monthlyPac; final String? platform;
  const InvestmentPosition({required this.id,required this.name,required this.type,required this.invested,required this.currentValue,this.monthlyPac=0,this.platform});
  double get gain=>currentValue-invested; double get gainPercent=>invested==0?0:gain/invested*100;
  Map<String,Object?> toMap()=>{'id':id,'name':name,'type':type.name,'invested':invested,'current_value':currentValue,'monthly_pac':monthlyPac,'platform':platform};
  factory InvestmentPosition.fromMap(Map<String,Object?> m)=>InvestmentPosition(id:m['id'] as String,name:m['name'] as String,type:InvestmentType.values.firstWhere((e)=>e.name==m['type']),invested:(m['invested'] as num).toDouble(),currentValue:(m['current_value'] as num).toDouble(),monthlyPac:(m['monthly_pac'] as num?)?.toDouble()??0,platform:m['platform'] as String?);
}

class InvestmentAnalysis {
  final String assetId,assetName,riskLevel,trend,summary; final double currentValue,portfolioWeight,gainPercent; final List<String> positiveFactors,risks,scenarios; final List<InvestmentViewAction> actions; final DateTime generatedAt;
  const InvestmentAnalysis({required this.assetId,required this.assetName,required this.currentValue,required this.portfolioWeight,required this.gainPercent,required this.riskLevel,required this.trend,required this.positiveFactors,required this.risks,required this.scenarios,required this.actions,required this.summary,required this.generatedAt});
}

class FinancialPlan {
  final double income,recurringMonthly,spentThisMonth,earnedThisMonth,currentBalance,overdraftLimit,recoveryAmount,spendableUntilSalary,weeklySpendable,goalContributions,investmentContributions;
  final int daysUntilSalary; final FinancialStatus status;
  const FinancialPlan({required this.income,required this.recurringMonthly,required this.spentThisMonth,required this.earnedThisMonth,required this.currentBalance,required this.overdraftLimit,required this.recoveryAmount,required this.spendableUntilSalary,required this.weeklySpendable,required this.daysUntilSalary,required this.status,required this.goalContributions,required this.investmentContributions});
  double get overdraftRemaining=>(overdraftLimit-(currentBalance<0?currentBalance.abs():0)).clamp(0,overdraftLimit);
}
