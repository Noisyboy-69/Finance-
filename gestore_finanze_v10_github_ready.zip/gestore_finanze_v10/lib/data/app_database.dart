import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/models.dart';
class AppDatabase {
  static final instance=AppDatabase._(); AppDatabase._(); Database? _db;
  Future<Database> get database async=>_db??=await _open();
  Future<Database> _open() async=>openDatabase(join(await getDatabasesPath(),'gestore_finanze.db'),version:2,onCreate:(db,v)async{await _schema(db);},onUpgrade:(db,old,v)async{if(old<2){await db.execute("ALTER TABLE movements ADD COLUMN raw_text TEXT NOT NULL DEFAULT ''");await db.execute('CREATE TABLE IF NOT EXISTS goals (id TEXT PRIMARY KEY,name TEXT NOT NULL,target REAL NOT NULL,current REAL NOT NULL,monthly_contribution REAL NOT NULL DEFAULT 0)');await db.execute('CREATE TABLE IF NOT EXISTS investments (id TEXT PRIMARY KEY,name TEXT NOT NULL,type TEXT NOT NULL,invested REAL NOT NULL,current_value REAL NOT NULL,monthly_pac REAL NOT NULL DEFAULT 0,platform TEXT)');await db.execute('CREATE TABLE IF NOT EXISTS merchant_rules (keyword TEXT PRIMARY KEY,category TEXT NOT NULL)');}});
  Future<void> _schema(Database db)async{
    await db.execute('CREATE TABLE settings (key TEXT PRIMARY KEY,value TEXT NOT NULL)');
    await db.execute('CREATE TABLE incomes (id INTEGER PRIMARY KEY AUTOINCREMENT,year INTEGER NOT NULL,month INTEGER NOT NULL,amount REAL NOT NULL,status TEXT NOT NULL,UNIQUE(year,month))');
    await db.execute('CREATE TABLE account_status (id INTEGER PRIMARY KEY CHECK(id=1),current_balance REAL NOT NULL,overdraft_limit REAL NOT NULL)');
    await db.execute('CREATE TABLE recurring_expenses (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,amount REAL NOT NULL,recurrence TEXT NOT NULL,category TEXT NOT NULL)');
    await db.execute('CREATE TABLE movements (id TEXT PRIMARY KEY,date TEXT NOT NULL,merchant TEXT NOT NULL,amount REAL NOT NULL,category TEXT NOT NULL,source TEXT NOT NULL,raw_text TEXT NOT NULL)');
    await db.execute('CREATE TABLE goals (id TEXT PRIMARY KEY,name TEXT NOT NULL,target REAL NOT NULL,current REAL NOT NULL,monthly_contribution REAL NOT NULL DEFAULT 0)');
    await db.execute('CREATE TABLE investments (id TEXT PRIMARY KEY,name TEXT NOT NULL,type TEXT NOT NULL,invested REAL NOT NULL,current_value REAL NOT NULL,monthly_pac REAL NOT NULL DEFAULT 0,platform TEXT)');
    await db.execute('CREATE TABLE merchant_rules (keyword TEXT PRIMARY KEY,category TEXT NOT NULL)');
  }
  Future<void> setting(String k,String v)async=>(await database).insert('settings',{'key':k,'value':v},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<String?> getSetting(String k)async{final r=await(await database).query('settings',where:'key=?',whereArgs:[k],limit:1);return r.isEmpty?null:r.first['value'] as String;}
  Future<void> saveIncome(MonthIncome x)async=>(await database).insert('incomes',x.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  Future<MonthIncome?> income(int y,int m)async{final r=await(await database).query('incomes',where:'year=? AND month=?',whereArgs:[y,m],limit:1);return r.isEmpty?null:MonthIncome.fromMap(r.first);}
  Future<void> saveAccount(CurrentAccountStatus x)async=>(await database).insert('account_status',{'id':1,'current_balance':x.currentBalance,'overdraft_limit':x.overdraftLimit},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<CurrentAccountStatus?> account()async{final r=await(await database).query('account_status',limit:1);if(r.isEmpty)return null;return CurrentAccountStatus(currentBalance:(r.first['current_balance'] as num).toDouble(),overdraftLimit:(r.first['overdraft_limit'] as num).toDouble());}
  Future<void> addRecurring(RecurringExpense x)async=>(await database).insert('recurring_expenses',x.toMap());
  Future<List<RecurringExpense>> recurring()async=>(await database).query('recurring_expenses',orderBy:'id DESC').then((r)=>r.map(RecurringExpense.fromMap).toList());
  Future<void> addMovement(Movement x)async=>(await database).insert('movements',x.toMap(),conflictAlgorithm:ConflictAlgorithm.ignore);
  Future<List<Movement>> movements({int? year,int? month})async{final db=await database;String? where;List<Object?>? args;if(year!=null&&month!=null){where='date>=? AND date<?';args=[DateTime(year,month,1).toIso8601String(),DateTime(year,month+1,1).toIso8601String()];}final r=await db.query('movements',where:where,whereArgs:args,orderBy:'date DESC');return r.map(Movement.fromMap).toList();}
  Future<void> saveRule(String keyword,String category)async=>(await database).insert('merchant_rules',{'keyword':keyword.toLowerCase(),'category':category},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<List<CategoryRule>> rules()async{final r=await(await database).query('merchant_rules');return r.map((x)=>CategoryRule(x['keyword'] as String,x['category'] as String)).toList();}
  Future<void> saveGoal(Goal x)async=>(await database).insert('goals',{'id':x.id,'name':x.name,'target':x.target,'current':x.current,'monthly_contribution':x.monthlyContribution},conflictAlgorithm:ConflictAlgorithm.replace);
  Future<List<Goal>> goals()async{final r=await(await database).query('goals');return r.map((x)=>Goal(id:x['id'] as String,name:x['name'] as String,target:(x['target'] as num).toDouble(),current:(x['current'] as num).toDouble(),monthlyContribution:(x['monthly_contribution'] as num).toDouble())).toList();}
  Future<void> saveInvestment(InvestmentPosition x)async=>(await database).insert('investments',x.toMap(),conflictAlgorithm:ConflictAlgorithm.replace);
  Future<List<InvestmentPosition>> investments()async=>(await(await database).query('investments',orderBy:'name')).map(InvestmentPosition.fromMap).toList();
}
class CategoryRule {final String keyword,category;const CategoryRule(this.keyword,this.category);}
