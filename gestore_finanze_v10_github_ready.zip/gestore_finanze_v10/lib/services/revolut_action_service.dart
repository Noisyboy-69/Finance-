import 'package:url_launcher/url_launcher.dart';
class RevolutActionService { static Future<bool> openRevolut()async=>launchUrl(Uri.parse('revolut://'),mode:LaunchMode.externalApplication); }
