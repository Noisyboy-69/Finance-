import '../models/models.dart';
class CategoryRule { final String keyword,category; const CategoryRule(this.keyword,this.category); }
class ParsedMovement { final String merchant,category; final double amount; ParsedMovement(this.merchant,this.amount,this.category); }
class MovementParser {
  static const defaultRules=<CategoryRule>[
    CategoryRule('coop','Alimentari'),CategoryRule('conad','Alimentari'),CategoryRule('esselunga','Alimentari'),CategoryRule('carrefour','Alimentari'),CategoryRule('lidl','Alimentari'),CategoryRule('aldi','Alimentari'),CategoryRule('amazon','Shopping'),CategoryRule('netflix','Abbonamenti'),CategoryRule('spotify','Abbonamenti'),CategoryRule('disney','Abbonamenti'),CategoryRule('eni','Carburante'),CategoryRule('q8','Carburante'),CategoryRule('uber','Trasporti'),CategoryRule('trenitalia','Trasporti'),CategoryRule('ryanair','Viaggi'),CategoryRule('booking','Viaggi'),CategoryRule('mcdonald','Ristoranti'),CategoryRule('burger','Ristoranti'),CategoryRule('osteria','Ristoranti'),CategoryRule('ristorante','Ristoranti')];
  static Movement? parse(String text,{List<CategoryRule> learned=const [],DateTime? date}){
    final amount=_amount(text); if(amount<=0)return null; final merchant=_merchant(text); if(merchant.isEmpty)return null; final n=merchant.toLowerCase(); var category='Altro'; for(final r in [...learned,...defaultRules]){if(n.contains(r.keyword.toLowerCase())){category=r.category;break;}}
    return Movement(id:'rev_${DateTime.now().microsecondsSinceEpoch}',date:date??DateTime.now(),merchant:merchant,amount:amount,category:category,source:'revolut_notification',rawText:text);
  }
  static double _amount(String t){for(final p in [RegExp(r'€\s*([0-9][0-9\.,]*)'),RegExp(r'([0-9][0-9\.,]*)\s*€')]){final m=p.firstMatch(t);if(m!=null){final raw=m.group(1)!.replaceAll('.','').replaceAll(',','.');return double.tryParse(raw)??0;}}return 0;}
  static String _merchant(String t){final parts=t.split('—');if(parts.length>1)return parts.last.trim();final hy=t.split('-');if(hy.length>1)return hy.last.trim();final m=RegExp(r'(?:Pagamento|Pagato|Acquisto).*?(?:€|EUR).*?\s([A-Za-zÀ-ÿ0-9 &.\']+)$',caseSensitive:false).firstMatch(t);return m?.group(1)?.trim()??'';}
}
