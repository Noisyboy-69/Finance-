import 'package:flutter/services.dart';
import '../data/app_database.dart';
import 'movement_parser.dart';
class RevolutNotificationBridge {
  static const channel=EventChannel('gestore_finanze/revolut_notifications');
  static void start() { channel.receiveBroadcastStream().listen((event)async{if(event is! Map)return;final text='${event['title']??''} ${event['text']??''} ${event['bigText']??''}';final movement=MovementParser.parse(text,learned:await AppDatabase.instance.rules());if(movement!=null)await AppDatabase.instance.addMovement(movement);}); }
}
