import '../models/models.dart';
class FinancialEngine {
  static FinancialPlan build({required MonthIncome income,required CurrentAccountStatus account,required List<RecurringExpense> recurring,required List<Movement> movements,DateTime? now}) {
    final d=now??DateTime.now();
    final recurringMonthly=recurring.fold(0.0,(s,e)=>s+e.monthlyEquivalent);
    final spent=movements.where((m)=>m.amount>0).fold(0.0,(s,m)=>s+m.amount);
    final recovery=account.currentBalance<0?(income.amount*0.20).clamp(0,account.currentBalance.abs()).toDouble():0.0;
    final available=account.currentBalance>0?account.currentBalance:0.0;
    final spendable=(available-recurringMonthly-recovery-spent).clamp(0,double.infinity).toDouble();
    var next=DateTime(d.year,d.month,15); if(!next.isAfter(d)) next=DateTime(d.year,d.month+1,15);
    final days=next.difference(d).inDays.clamp(1,31); final weekly=spendable/(days/7).clamp(1,5);
    FinancialStatus status=FinancialStatus.stable;
    if(account.currentBalance<0){status=account.overdraftLimit>0&&account.currentBalance.abs()>=account.overdraftLimit*.9?FinancialStatus.critical:FinancialStatus.recovery;} else if(income.amount>0&&spendable<income.amount*.1) status=FinancialStatus.attention;
    return FinancialPlan(income:income.amount,recurringMonthly:recurringMonthly,spentThisMonth:spent,currentBalance:account.currentBalance,overdraftLimit:account.overdraftLimit,recoveryAmount:recovery,spendableUntilSalary:spendable,weeklySpendable:weekly,daysUntilSalary:days,status:status);
  }
}
