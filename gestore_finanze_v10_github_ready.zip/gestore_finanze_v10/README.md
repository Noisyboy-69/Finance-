# Gestore Finanze — V10

App Flutter Android-first per gestione personale delle finanze.

## Stato
V10 consolida in un unico progetto:
- Home e budget dinamico
- entrate previste/effettive
- saldo e scoperto
- recupero da saldo negativo
- movimenti e categorie
- import automatico dalle notifiche Revolut
- regole merchant apprendibili
- obiettivi
- sezione Investimenti separata
- analisi/scenari di investimenti
- watchlist
- suggerimenti di allocazione prudenti
- apertura di Revolut dopo conferma dell'utente

## Nota build
Questo ambiente di lavoro non contiene Flutter SDK, quindi la compilazione APK non è stata eseguita qui.
Per la prima build usare Flutter stable + Android SDK/Android Studio.

Package Android: com.gestorefinanze.app
Database: SQLite locale, schema versione 2.
