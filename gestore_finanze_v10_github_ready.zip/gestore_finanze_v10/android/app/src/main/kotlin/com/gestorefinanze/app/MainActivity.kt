package com.gestorefinanze.app

import android.content.Intent
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "gestore_finanze/revolut_notifications")
            .setStreamHandler(RevolutStreamHandler)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "gestore_finanze/revolut_settings")
            .setMethodCallHandler { call, result ->
                if (call.method == "openNotificationListenerSettings") {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    result.success(true)
                } else result.notImplemented()
            }
    }
}
