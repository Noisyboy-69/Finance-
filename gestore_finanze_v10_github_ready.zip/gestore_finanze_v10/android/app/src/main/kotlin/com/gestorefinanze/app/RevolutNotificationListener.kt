package com.gestorefinanze.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import io.flutter.plugin.common.EventChannel

object RevolutStreamHandler : EventChannel.StreamHandler {
    private var sink: EventChannel.EventSink? = null
    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) { sink = events }
    override fun onCancel(arguments: Any?) { sink = null }
    fun emit(payload: Map<String, Any?>) { sink?.success(payload) }
}

class RevolutNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.revolut.revolut") return
        val extras = sbn.notification.extras
        RevolutStreamHandler.emit(mapOf(
            "title" to (extras.getCharSequence("android.title")?.toString() ?: ""),
            "text" to (extras.getCharSequence("android.text")?.toString() ?: ""),
            "bigText" to (extras.getCharSequence("android.bigText")?.toString() ?: "")
        ))
    }
}
